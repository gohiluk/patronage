/** Automatically generated file. DO NOT MODIFY */
package com.example.tomasz.nosal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}