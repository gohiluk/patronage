package com.example.tomasz.nosal;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;

public class SplashActivity extends Activity {

	private Thread threadMainActivity;
	private boolean stop = false;
	private static final int SPLASHTIME = 4000;
	private static final int PARTOFSPLASHTIME = 100;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		threadMainActivity = new Thread() {
			@Override
			public void run() {
				try {
					int time = 0;
					while (!stop && time <= SPLASHTIME) {
						sleep(PARTOFSPLASHTIME);
						time += PARTOFSPLASHTIME;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				} finally {
					if (!stop) {
						startActivity(new Intent(getApplicationContext(),
								MainActivity.class));
						finish();
					} else {
						finish();
					}
				}
			}
		};
		threadMainActivity.start();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {	
			if (threadMainActivity.isAlive())
				this.stop = true;		
		        return true;
	    } else{
	    return super.onKeyDown(keyCode, event);
	    }
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splash, menu);
		return true;
	}

}
